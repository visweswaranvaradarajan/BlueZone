﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueZoneConnect
{
    public class clsBZ
    {
        private string _usr;
        private string _pwd;
        public BZWHLLLib.WhllObj Session;
        private string _sessionID;


        private void startSession()
        {
            if (Session == null)
            {
                Session = new BZWHLLLib.WhllObj();
                Session.Connect(_sessionID);

            }
        }

        public string getValue(int row, int colm, int valSize)
        {
            Object tmp = "";
            Session.ReadScreen(out tmp, valSize, row, colm);
            return tmp.ToString();
        }

        public void putValue(string value, int row, int colm)
        {
            Session.WaitReady(0, 51);
            Session.SetCursor(row, colm);
            Session.SendKey(value);
            Session.WaitReady(0, 51);
        }

    }
}
